import tkinter
from tkinter import *
# Importing all the required Libraries


from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)

#Importing matplotlib
import matplotlib.pyplot as mpl

from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure

#Impoting numpy

import numpy as np

#Defining values for x and y
x = np.linspace(-50, 51, 200)
y = np.linspace(-50, 51, 200)
#meshgrid makes an array, this is useful in defining functions
x, y = np.meshgrid(x, y)

#Axes() as a function, this will highlight our origin
def axes():
    mpl.grid()
    mpl.axhline(0, alpha= .2, linewidth= 2, color='k' )
    #Printing Horizontal line, X axis
    mpl.axvline(0, alpha= .2, linewidth= 2, color='k' )
    #Printing Vertical line, Y axis
    #mpl.axis('equal')


def CalulateST():
    print('straightlineX')
    print('1. Parabola in standard equation')
    a = float(straightlineX)
    parabola = (y**2 - 4*a*x)
    axes()
    mpl.contour(x, y, parabola, [0], colors='k')
    mpl.show()
    

def StraightBut():
  global screenstraight
  print('StraightBut Working')
  screenstraight = Toplevel(screenloop)
  screenstraight.title("StraightBut")
  screenstraight.geometry("1080x720")
  Label(screenstraight, text = "Graphs with Matpltlib", bg = "grey", width = "300", height = "2", font = ("Calibri", 13)).pack()
  global straightlineX
  global straightlineY
  global straightlineK
  
  straightlineX = StringVar()
  straightlineY = StringVar()

  Label(screenstraight, text = "Please enter details below").pack()
  Label(screenstraight, text = "", bg = "#A55D35").pack()
  Label(screenstraight, text = "Coefficient of X").pack()
 
  straightlineX_entry = Entry(screenstraight, textvariable = straightlineX)
  straightlineX_entry.pack()
  Label(screenstraight, text = "").pack()
  Label(screenstraight, text = "Coefficient of Y").pack()
  straightlineY_entry =  Entry(screenstraight, textvariable = StraightlineY)
  straightlineY_entry.pack()

  Button(screenstraight, text = "Calculate", width = 10, height = 1, command = CalulateST).pack()



  
def ParabolaBut():
  global screenparabola
  screenparabola = Toplevel(screenloop)
  screenparabola.title("Parabola")
  screenparabola.geometry("1080x720")
  Label(screenparabola, text = "Graphs with Matpltlib", bg = "grey", width = "300", height = "2", font = ("Calibri", 13)).pack()
  Button(screenparabola, text = "PARABOLA STANDARD EQUATION", height = "2", width = "30", command = CalulatePrbo).pack()
  Button(screenparabola, text = "PARABOLA EXPANDED EQUATION", height = "2", width = "30", command = EllipseBut).pack()
  Button(screenparabola, text = "RETURN TO HOMEPAGE", height = "2", width = "30", command = Homescreen).pack()


def CalulatePrbo():
    global testscreen
    testscreen = Toplevel(screenloop)
    print('testing')
    print('Parabola in standard equation')
    test = StringVar()
    test_entry = Entry(testscreen, textvariable = test)
    test_entry.pack()
    a = int(test)
    
    parabola = (y**2 - 4*a*x)
    axes()
    mpl.contour(x, y, parabola, [0], colors='k')
    mpl.show()

    fig = Figure(figsize=(5, 4), dpi=100)
    t = np.arange(0, 3, .01)
    fig.add_subplot(111).plot(t, 2 * np.sin(2 * np.pi * t))

    canvas = FigureCanvasTkAgg(fig, master=screenparabola)  # A tk.DrawingArea.
    canvas.draw()
    canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)

    toolbar = NavigationToolbar2Tk(canvas, screenparabola)
    toolbar.update()
    canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)


def EllipseBut():
  global screenellipse
  print('HyperbolaBut Working')
  screenellipse = Toplevel(screenloop)
  screenellipse.title("Ellipse")
  screenellipse.geometry("1080x720")
  Label(screenellipse, text = "Graphs with Matpltlib", bg = "grey", width = "300", height = "2", font = ("Calibri", 13)).pack()
  Button(screenellipse, text = "Ellipse STANDARD EQUATION", height = "2", width = "30", command = ParabolaBut).pack()
  Button(screenellipse, text = "Ellipse EXPANDED EQUATION", height = "2", width = "30", command = EllipseBut).pack()
  Button(screenellipse, text = "RETURN TO HOMEPAGE", height = "2", width = "30", command = Homescreen).pack()
def HyperbolaBut():
  global screenhyperbola
  print('HyperbolaBut Working')
  screenhyperbola = Toplevel(screenloop)
  screenhyperbola.title("Hyperbola")
  screenhyperbola.geometry("1080x720")
  Label(screenhyperbola, text = "Graphs with Matpltlib", bg = "grey", width = "300", height = "2", font = ("Calibri", 13)).pack()
  Button(screenhyperbola, text = "Hyperbola STANDARD EQUATION", height = "2", width = "30", command = ParabolaBut).pack()
  Button(screenhyperbola, text = "Hyperbola EXPANDED EQUATION", height = "2", width = "30", command = EllipseBut).pack()
  Button(screenhyperbola, text = "RETURN TO HOMEPAGE", height = "2", width = "30", command = Homescreen).pack()


def Homescreen():
  global screenloop
  print('main_screen Working')
  screenloop = Tk()
  
  photo = PhotoImage(file = r"images.png")
  labelphoto = Label(screenloop, image = photo)
  labelphoto.pack()
  screenloop.title("MainScreen")
  screenloop.geometry("1080x720")
  Label(text = "Graphs with Matpltlib", bg = "grey", width = "300", height = "2", font = ("Calibri", 13)).pack()
  Button(text = "Straight Lines", height = "2", width = "30", command = StraightBut).pack()
  Button(text = "PARABOLA", height = "2", width = "30", command = ParabolaBut).pack()
  Button(text = "ELLIPSE", height = "2", width = "30", command = EllipseBut).pack()
  Button(text = "HYPERBOLA", height = "2", width = "30", command = HyperbolaBut).pack()

  screenloop.mainloop()

Homescreen()
















































